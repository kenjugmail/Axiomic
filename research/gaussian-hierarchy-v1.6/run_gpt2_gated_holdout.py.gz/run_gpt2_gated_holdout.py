from __future__ import annotations

import argparse
import copy
import json
import math
import os
import platform
import re
import time
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd
import torch
from scipy.cluster.hierarchy import cut_tree, linkage
from scipy.spatial.distance import squareform


@dataclass(frozen=True)
class Env:
    name: str
    A: np.ndarray
    Y: np.ndarray


def energy(env: Env, eps: float = 1e-12) -> float:
    return float(np.sum(env.Y * env.Y) / env.Y.shape[0] + eps)


def risks(envs: Sequence[Env], subset: np.ndarray, B: np.ndarray) -> np.ndarray:
    return np.asarray(
        [
            np.sum((env.Y - env.A[:, subset] @ B) ** 2)
            / (env.Y.shape[0] * energy(env))
            for env in envs
        ],
        dtype=np.float64,
    )


def normalized_refit(
    envs: Sequence[Env], subset: np.ndarray, q: np.ndarray, ridge: float = 2e-6
) -> np.ndarray:
    q = np.asarray(q, dtype=np.float64)
    if q.ndim != 1 or q.shape[0] != len(envs) or np.any(q < 0) or q.sum() <= 0:
        raise ValueError("q must be a nonnegative vector matching envs")
    q = q / q.sum()
    xs: list[np.ndarray] = []
    ys: list[np.ndarray] = []
    for weight, env in zip(q, envs, strict=True):
        scale = np.sqrt(weight / (env.Y.shape[0] * energy(env)))
        xs.append(env.A[:, subset] * scale)
        ys.append(env.Y * scale)
    X = np.concatenate(xs, axis=0)
    T = np.concatenate(ys, axis=0)
    k = len(subset)
    if k <= X.shape[0]:
        return np.linalg.solve(X.T @ X + ridge * np.eye(k), X.T @ T)
    return X.T @ np.linalg.solve(X @ X.T + ridge * np.eye(X.shape[0]), T)


def minimax_refit(
    envs: Sequence[Env],
    subset: np.ndarray,
    ridge: float = 2e-6,
    iterations: int = 10,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    q = np.full(len(envs), 1.0 / len(envs), dtype=np.float64)
    log_q = np.log(q)
    B = normalized_refit(envs, subset, q, ridge)
    r = risks(envs, subset, B)
    best = (float(r.max()), B.copy(), q.copy(), r.copy())
    for step in range(iterations):
        log_q += (1.5 / np.sqrt(step + 1.0)) * (r - r.mean())
        log_q -= log_q.max()
        q = np.exp(log_q)
        q /= q.sum()
        B = normalized_refit(envs, subset, q, ridge)
        r = risks(envs, subset, B)
        if float(r.max()) < best[0]:
            best = (float(r.max()), B.copy(), q.copy(), r.copy())
    return best[1], best[2], best[3]


GUTENBERG = {
    "frankenstein": "https://www.gutenberg.org/files/84/84-0.txt",
    "moby": "https://www.gutenberg.org/files/2701/2701-0.txt",
    "macbeth": "https://www.gutenberg.org/files/1533/1533-0.txt",
    "othello": "https://www.gutenberg.org/files/1531/1531-0.txt",
}

CPYTHON = {
    "asyncio": "https://raw.githubusercontent.com/python/cpython/v3.13.0/Lib/asyncio/base_events.py",
    "pathlib": "https://raw.githubusercontent.com/python/cpython/v3.13.0/Lib/pathlib/_local.py",
}


def download(url: str, path: Path) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        with urllib.request.urlopen(url, timeout=90) as response:
            path.write_bytes(response.read())
    return path.read_text(encoding="utf-8", errors="replace")


def strip_gutenberg(text: str) -> str:
    start = re.search(
        r"\*\*\* START OF (?:THE|THIS) PROJECT GUTENBERG EBOOK.*?\*\*\*",
        text,
        re.I,
    )
    end = re.search(
        r"\*\*\* END OF (?:THE|THIS) PROJECT GUTENBERG EBOOK.*?\*\*\*",
        text,
        re.I,
    )
    if start:
        text = text[start.end() :]
    if end:
        text = text[: end.start()]
    return text.strip()


def corpora(cache: Path) -> dict[str, tuple[str, str]]:
    books = {
        name: strip_gutenberg(download(url, cache / f"{name}.txt"))
        for name, url in GUTENBERG.items()
    }
    code = {
        name: download(url, cache / f"cpython-{name}-v3.13.0.py")
        for name, url in CPYTHON.items()
    }
    return {
        "prose": (books["frankenstein"], books["moby"]),
        "dialogue": (books["macbeth"], books["othello"]),
        "code": (code["asyncio"], code["pathlib"]),
    }


def chunks(tokenizer, text: str, length: int, count: int, offset: int) -> torch.Tensor:
    ids = tokenizer.encode(text, add_special_tokens=False, verbose=False)
    if not ids:
        raise ValueError("corpus tokenization produced no tokens")
    need = offset + length * count
    if len(ids) < need:
        ids = (ids * math.ceil(need / len(ids)))[:need]
    rows = [ids[offset + i * length : offset + (i + 1) * length] for i in range(count)]
    if any(len(row) != length for row in rows):
        raise RuntimeError("failed to build fixed-length token chunks")
    return torch.tensor(rows, dtype=torch.long)


def collect_activations(
    model, ids: torch.Tensor, layer: int, device: torch.device
) -> np.ndarray:
    captured: list[torch.Tensor] = []

    def hook(_module, args):
        captured.append(args[0].detach().float().cpu())

    handle = model.transformer.h[layer].mlp.c_proj.register_forward_pre_hook(hook)
    try:
        with torch.no_grad():
            for batch in ids.split(2):
                model(batch.to(device))
    finally:
        handle.remove()
    return (
        torch.cat(captured)
        .reshape(-1, captured[0].shape[-1])
        .numpy()
        .astype(np.float64)
    )


def perplexity(model, ids: torch.Tensor, device: torch.device) -> float:
    nll = 0.0
    tokens = 0
    model.eval()
    with torch.no_grad():
        for batch in ids.split(2):
            batch = batch.to(device)
            out = model(batch, labels=batch)
            count = batch.numel() - batch.shape[0]
            nll += float(out.loss) * count
            tokens += count
    return float(math.exp(nll / tokens))


def output_basis(envs: Sequence[Env], rank: int) -> np.ndarray:
    Y = np.concatenate([env.Y for env in envs], axis=0).astype(np.float64)
    Y -= Y.mean(axis=0, keepdims=True)
    _, _, vt = np.linalg.svd(Y, full_matrices=False)
    return vt[: min(rank, vt.shape[0])].T


@dataclass(frozen=True)
class Sketch:
    raw: np.ndarray
    mean: np.ndarray
    variance: np.ndarray
    uncertainty_fraction: np.ndarray


def operator_sketches(
    envs: Sequence[Env],
    outgoing: np.ndarray,
    *,
    rank: int,
    probes: int,
    bootstraps: int,
    variance_temperature: float,
    seed: int,
) -> Sketch:
    rng = np.random.default_rng(seed)
    P = output_basis(envs, rank)
    projected_writes = outgoing @ P
    fixed_probes: list[np.ndarray] = []
    raw_parts: list[np.ndarray] = []
    for env_index, env in enumerate(envs):
        local = np.random.default_rng(seed + 1009 * (env_index + 1))
        G = local.normal(size=(probes, env.A.shape[0]))
        G /= np.sqrt(probes * env.A.shape[0])
        fixed_probes.append(G)
        projected = (G @ env.A).T
        z = np.einsum("mp,mr->mpr", projected, projected_writes)
        raw_parts.append(z.reshape(outgoing.shape[0], -1) / np.sqrt(energy(env)))
    raw = np.concatenate(raw_parts, axis=1).astype(np.float64)

    samples: list[np.ndarray] = []
    for _ in range(bootstraps):
        parts: list[np.ndarray] = []
        for env, G in zip(envs, fixed_probes, strict=True):
            weights = rng.exponential(size=env.A.shape[0])
            weights /= weights.mean()
            projected = (G @ (env.A * weights[:, None])).T
            z = np.einsum("mp,mr->mpr", projected, projected_writes)
            parts.append(z.reshape(outgoing.shape[0], -1) / np.sqrt(energy(env)))
        samples.append(np.concatenate(parts, axis=1))
    boot = np.stack(samples, axis=0)
    mean = boot.mean(axis=0)
    sample_variance = boot.var(axis=0, ddof=1)
    effective_variance = variance_temperature * sample_variance
    prior_variance = np.maximum(
        mean.var(axis=0, ddof=1) - effective_variance.mean(axis=0), 1e-12
    )
    gain = prior_variance[None, :] / (
        prior_variance[None, :] + effective_variance
    )
    refined_mean = gain * mean
    refined_variance = (
        prior_variance[None, :]
        * effective_variance
        / (prior_variance[None, :] + effective_variance)
    )
    signal = np.sum(refined_mean**2, axis=1)
    uncertainty = np.sum(refined_variance, axis=1)
    uncertainty_fraction = uncertainty / (signal + uncertainty + 1e-12)
    return Sketch(
        raw=raw,
        mean=refined_mean,
        variance=refined_variance,
        uncertainty_fraction=uncertainty_fraction,
    )


def cosine(features: np.ndarray) -> np.ndarray:
    norm = np.linalg.norm(features, axis=1)
    return np.clip(
        (features @ features.T) / (norm[:, None] * norm[None, :] + 1e-12),
        -1.0,
        1.0,
    )


def gaussian_cosine(mean: np.ndarray, variance: np.ndarray) -> np.ndarray:
    expected_sq = np.sum(mean**2 + variance, axis=1)
    return np.clip(
        (mean @ mean.T)
        / (np.sqrt(expected_sq[:, None] * expected_sq[None, :]) + 1e-12),
        -1.0,
        1.0,
    )


def tree_from_similarity(similarity: np.ndarray) -> np.ndarray:
    distance = np.maximum(1.0 - similarity, 0.0)
    distance = 0.5 * (distance + distance.T)
    np.fill_diagonal(distance, 0.0)
    n = len(distance)
    ii, jj = np.triu_indices(n, 1)
    distance[ii, jj] += 1e-12 * (1 + ii + jj / max(n, 1))
    distance[jj, ii] = distance[ii, jj]
    return linkage(squareform(distance, checks=False), method="average")


def subset_from_tree(
    tree: np.ndarray,
    active: np.ndarray,
    raw_features: np.ndarray,
    keep: int,
) -> tuple[np.ndarray, list[list[int]]]:
    labels = cut_tree(tree, n_clusters=[keep]).reshape(-1)
    representatives: list[int] = []
    clusters: list[list[int]] = []
    for label in np.unique(labels):
        local_members = np.flatnonzero(labels == label)
        global_members = active[local_members]
        block = raw_features[local_members]
        block_similarity = cosine(block)
        raw_energy = np.sum(block**2, axis=1)
        positive = raw_energy[raw_energy > 0]
        scale = float(np.median(positive)) if len(positive) else 1.0
        score = block_similarity.mean(axis=1) + 0.05 * np.log1p(
            raw_energy / (scale + 1e-12)
        )
        representatives.append(int(global_members[int(np.argmax(score))]))
        clusters.append([int(x) for x in global_members])
    return np.sort(np.asarray(representatives, dtype=int)), clusters


def build_tree_family(
    sketch: Sketch, outgoing: np.ndarray, alphas: Sequence[float]
) -> tuple[np.ndarray, np.ndarray, dict[float, np.ndarray]]:
    active = np.flatnonzero(np.linalg.norm(outgoing, axis=1) > 1e-10)
    raw_features = sketch.raw[active]
    raw_similarity = cosine(raw_features)
    refined_similarity = gaussian_cosine(
        sketch.mean[active], sketch.variance[active]
    )
    trees: dict[float, np.ndarray] = {}
    for alpha in alphas:
        similarity = np.clip(
            (1.0 - alpha) * raw_similarity + alpha * refined_similarity,
            -1.0,
            1.0,
        )
        trees[float(alpha)] = tree_from_similarity(similarity)
    return active, raw_features, trees


def diagonal_subset(
    envs: Sequence[Env],
    outgoing: np.ndarray,
    incoming: np.ndarray,
    keep: int,
    method: str,
) -> np.ndarray:
    write_sq = np.sum(outgoing**2, axis=1)
    second = np.stack(
        [np.mean(env.A**2, axis=0) * write_sq / energy(env) for env in envs]
    )
    if method == "magnitude":
        score = np.linalg.norm(incoming, axis=0) * np.sqrt(write_sq)
    elif method == "wanda":
        score = (
            np.mean([np.mean(np.abs(env.A), axis=0) for env in envs], axis=0)
            * np.sqrt(write_sq)
        )
    elif method == "robust_capacity":
        score = second.max(axis=0)
    else:
        raise ValueError(method)
    return np.sort(np.argpartition(score, -keep)[-keep:])


def rebuild(model, layer: int, subset: np.ndarray, B: np.ndarray) -> None:
    from transformers.pytorch_utils import Conv1D

    mlp = model.transformer.h[layer].mlp
    old_fc = mlp.c_fc
    old_proj = mlp.c_proj
    device = old_fc.weight.device
    dtype = old_fc.weight.dtype
    model_dim = old_fc.weight.shape[0]
    keep = len(subset)
    fc = Conv1D(keep, model_dim).to(device=device, dtype=dtype)
    proj = Conv1D(model_dim, keep).to(device=device, dtype=dtype)
    with torch.no_grad():
        fc.weight.copy_(old_fc.weight[:, subset])
        fc.bias.copy_(old_fc.bias[subset])
        proj.weight.copy_(torch.as_tensor(B, device=device, dtype=dtype))
        proj.bias.copy_(old_proj.bias)
    mlp.c_fc = fc
    mlp.c_proj = proj


def split_fit_validation(envs: Sequence[Env], fit_fraction: float = 0.75):
    fit: list[Env] = []
    validation: list[Env] = []
    for env in envs:
        boundary = int(round(env.A.shape[0] * fit_fraction))
        boundary = min(max(boundary, 1), env.A.shape[0] - 1)
        fit.append(Env(env.name, env.A[:boundary], env.Y[:boundary]))
        validation.append(Env(env.name, env.A[boundary:], env.Y[boundary:]))
    return fit, validation


def choose_alpha_by_validation(
    fit_envs: Sequence[Env],
    validation_envs: Sequence[Env],
    outgoing: np.ndarray,
    keep: int,
    *,
    alpha_grid: Sequence[float],
    seed: int,
    variance_temperature: float,
) -> tuple[float, float, dict[str, float]]:
    sketch = operator_sketches(
        fit_envs,
        outgoing,
        rank=24,
        probes=4,
        bootstraps=24,
        variance_temperature=variance_temperature,
        seed=seed,
    )
    active, raw_features, trees = build_tree_family(sketch, outgoing, alpha_grid)
    scores: dict[str, float] = {}
    best_alpha = 0.0
    best_score = math.inf
    for alpha in sorted(alpha_grid):
        subset, _ = subset_from_tree(trees[float(alpha)], active, raw_features, keep)
        B, _, _ = minimax_refit(fit_envs, subset, iterations=4)
        score = float(risks(validation_envs, subset, B).max())
        scores[f"{alpha:.2f}"] = score
        if score < best_score - 1e-12:
            best_alpha = float(alpha)
            best_score = score
    return best_alpha, best_score, scores


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--model", default="openai-community/gpt2")
    parser.add_argument(
        "--revision", default="607a30d783dfa663caf39e06633721c8d4cfcd7e"
    )
    parser.add_argument("--layer", type=int, required=True)
    parser.add_argument("--length", type=int, default=64)
    parser.add_argument("--cal-chunks", type=int, default=4)
    parser.add_argument("--eval-chunks", type=int, default=8)
    parser.add_argument("--cal-offset", type=int, default=64)
    parser.add_argument("--eval-offset", type=int, default=128)
    parser.add_argument("--sketch-seed", type=int, default=20260801)
    parser.add_argument("--cache-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    from transformers import AutoModelForCausalLM, AutoTokenizer, __version__ as tv

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    tokenizer = AutoTokenizer.from_pretrained(args.model, revision=args.revision)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, revision=args.revision, dtype=torch.float32
    ).to(device).eval()
    resolved_revision = getattr(model.config, "_commit_hash", None)
    data = corpora(args.cache_dir)
    cal_ids = {
        name: chunks(
            tokenizer, pair[0], args.length, args.cal_chunks, args.cal_offset
        )
        for name, pair in data.items()
    }
    eval_ids = {
        name: chunks(
            tokenizer, pair[1], args.length, args.eval_chunks, args.eval_offset
        )
        for name, pair in data.items()
    }
    cal_A = {
        name: collect_activations(model, ids, args.layer, device)
        for name, ids in cal_ids.items()
    }
    eval_A = {
        name: collect_activations(model, ids, args.layer, device)
        for name, ids in eval_ids.items()
    }

    mlp = model.transformer.h[args.layer].mlp
    incoming = mlp.c_fc.weight.detach().float().cpu().numpy().astype(np.float64)
    outgoing = mlp.c_proj.weight.detach().float().cpu().numpy().astype(np.float64)
    cal_env = [Env(name, A, A @ outgoing) for name, A in cal_A.items()]
    eval_env = [Env(name, A, A @ outgoing) for name, A in eval_A.items()]
    fit_env, validation_env = split_fit_validation(cal_env)

    variance_temperature = 1.0 / 36.0
    alpha_grid = (0.0, 0.25, 0.5, 0.75, 1.0)
    full_sketch = operator_sketches(
        cal_env,
        outgoing,
        rank=24,
        probes=4,
        bootstraps=24,
        variance_temperature=variance_temperature,
        seed=args.sketch_seed,
    )
    active, raw_features, full_trees = build_tree_family(
        full_sketch, outgoing, alpha_grid
    )

    base_ppl = {
        name: perplexity(model, ids, device) for name, ids in eval_ids.items()
    }
    base_params = sum(parameter.numel() for parameter in model.parameters())
    width = outgoing.shape[0]
    rows: list[dict[str, object]] = []
    diagnostics: dict[str, object] = {}

    for reduction in (0.25, 0.50, 0.60):
        keep = width - int(round(width * reduction))
        selected_alpha, validation_score, alpha_scores = choose_alpha_by_validation(
            fit_env,
            validation_env,
            outgoing,
            keep,
            alpha_grid=alpha_grid,
            seed=args.sketch_seed + int(reduction * 10_000),
            variance_temperature=variance_temperature,
        )
        candidates: dict[str, np.ndarray] = {
            "magnitude": diagonal_subset(
                cal_env, outgoing, incoming, keep, "magnitude"
            ),
            "wanda": diagonal_subset(cal_env, outgoing, incoming, keep, "wanda"),
            "robust_capacity": diagonal_subset(
                cal_env, outgoing, incoming, keep, "robust_capacity"
            ),
        }
        raw_subset, raw_clusters = subset_from_tree(
            full_trees[0.0], active, raw_features, keep
        )
        gaussian_subset, gaussian_clusters = subset_from_tree(
            full_trees[1.0], active, raw_features, keep
        )
        gated_subset, gated_clusters = subset_from_tree(
            full_trees[selected_alpha], active, raw_features, keep
        )
        candidates["raw_merge_tree"] = raw_subset
        candidates["gaussian_raw_medoid"] = gaussian_subset
        candidates["validation_gated_blend"] = gated_subset
        diagnostics[str(int(reduction * 100))] = {
            "selected_alpha": selected_alpha,
            "validation_worst_risk": validation_score,
            "alpha_validation_risks": alpha_scores,
            "raw_cluster_count": len(raw_clusters),
            "gaussian_cluster_count": len(gaussian_clusters),
            "gated_cluster_count": len(gated_clusters),
            "raw_gaussian_jaccard": float(
                len(set(raw_subset) & set(gaussian_subset))
                / len(set(raw_subset) | set(gaussian_subset))
            ),
            "raw_gated_jaccard": float(
                len(set(raw_subset) & set(gated_subset))
                / len(set(raw_subset) | set(gated_subset))
            ),
        }

        for method, subset in candidates.items():
            started = time.perf_counter()
            B, q, seen = minimax_refit(cal_env, subset, iterations=10)
            held = risks(eval_env, subset, B)
            compressed = copy.deepcopy(model)
            rebuild(compressed, args.layer, subset, B)
            ppl = {
                name: perplexity(compressed, ids, device)
                for name, ids in eval_ids.items()
            }
            params = sum(parameter.numel() for parameter in compressed.parameters())
            rel = {
                name: (ppl[name] - base_ppl[name]) / base_ppl[name] for name in ppl
            }
            row: dict[str, object] = {
                "method": method,
                "width_reduction": reduction,
                "original_width": width,
                "retained_width": keep,
                "worst_layer_risk": float(held.max()),
                "mean_layer_risk": float(held.mean()),
                "worst_relative_ppl_change": float(max(rel.values())),
                "mean_relative_ppl_change": float(np.mean(list(rel.values()))),
                "parameter_reduction_total_fraction": (base_params - params)
                / base_params,
                "refit_weights": json.dumps(q.tolist()),
                "elapsed_seconds": time.perf_counter() - started,
                "selected_alpha": (
                    selected_alpha if method == "validation_gated_blend" else np.nan
                ),
                "validation_worst_risk": (
                    validation_score
                    if method == "validation_gated_blend"
                    else np.nan
                ),
            }
            row.update({f"ppl_{name}": value for name, value in ppl.items()})
            row.update(
                {f"relative_ppl_change_{name}": value for name, value in rel.items()}
            )
            rows.append(row)
            del compressed

    frame = pd.DataFrame(rows)
    frame.to_csv(args.output / "raw_results.csv", index=False)
    summary = {
        "status": "completed",
        "scope": (
            "Held-out GPT-2 Small diagnostic on one block, three new corpora, "
            "and a validation-gated blend of raw and Gaussian functional geometry."
        ),
        "model": args.model,
        "requested_revision": args.revision,
        "resolved_revision": resolved_revision,
        "layer": args.layer,
        "transformers": tv,
        "torch": torch.__version__,
        "python": platform.python_version(),
        "device": str(device),
        "calibration_tokens_per_domain": args.length * args.cal_chunks,
        "fit_tokens_per_domain": int(args.length * args.cal_chunks * 0.75),
        "validation_tokens_per_domain": int(args.length * args.cal_chunks * 0.25),
        "evaluation_tokens_per_domain": args.length * args.eval_chunks,
        "variance_temperature": variance_temperature,
        "alpha_grid": list(alpha_grid),
        "base_perplexity": base_ppl,
        "mean_gaussian_uncertainty_fraction": float(
            full_sketch.uncertainty_fraction.mean()
        ),
        "corpora": {
            "prose_calibration": "Frankenstein, Project Gutenberg 84",
            "prose_evaluation": "Moby-Dick, Project Gutenberg 2701",
            "dialogue_calibration": "Macbeth, Project Gutenberg 1533",
            "dialogue_evaluation": "Othello, Project Gutenberg 1531",
            "code_calibration": "CPython v3.13.0 Lib/asyncio/base_events.py",
            "code_evaluation": "CPython v3.13.0 Lib/pathlib/_local.py",
        },
        "rows": frame.to_dict(orient="records"),
        "diagnostics": diagnostics,
    }
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2))
    (args.output / "resolved_model_revision.txt").write_text(str(resolved_revision))
    print(frame.to_string(index=False))


if __name__ == "__main__":
    main()
